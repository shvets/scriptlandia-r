1. Run the command in order to download required dependencies:

>get-libraries.maven 

2. Run the script:

>example3.vm 