print ['a','list','of','strings']
