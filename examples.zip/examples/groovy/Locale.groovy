
println("Locale: " + java.util.Locale.getDefault());
