// groovyVersion.groovy

println("Groovy version: " + System.getProperty("groovy.version"));
