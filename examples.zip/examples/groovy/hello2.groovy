def hello = evaluate(new File("helloInclude.groovy"));

System.out.println(hello);

