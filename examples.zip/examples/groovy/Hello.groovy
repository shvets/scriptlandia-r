#!/usr/bin/env groovy

println("Hello world")
