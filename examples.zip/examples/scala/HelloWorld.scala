// HelloWorld.scala

object HelloWorld {

  def main(args: Array[String]) = {
    Console.println("Hello, world!")

    argv.toList foreach Console.println
  }

}

HelloWorld.main(args);
