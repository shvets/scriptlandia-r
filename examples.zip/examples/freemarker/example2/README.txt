Building the FAQ
================

Pre-requisites:

* You'll need Ant installed on your machine, version 1.3 or later should
  work just fine. Ant can be downloaded from http://jakarta.apache.org/ant/
  
* You need jython.jar accessible in the classpath (or in the ant lib directory).
  (For no good reason anyway... I hope the author will fix it. Hello Mr. Authot?)

Instructions:

* Run Ant as you would do normally. The FAQ should appear in an html
  sub-directory.
