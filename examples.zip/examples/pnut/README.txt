Run:

test.pnut -wait