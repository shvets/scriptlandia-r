>mvn help:active-profiles

>mvn antrun:run