1.

>build.fan

or

>fan.bat build.fan

or 

>sland.bat build.fan

2. 

>fan.bat hello

or

>fan.bat hello::Main

or

>hello.pod