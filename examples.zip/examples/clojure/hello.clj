(. (. System out) (println "Hello, world!"))

(.. System out (println "Hello, world!"))