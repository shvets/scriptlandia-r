This example shows how to work with XML data.

The etl.xml use XPath driver to query XML with XPath expressions.
Type scriptella or ant to run the example.
