1. Get required libraries:

>../get-libraries.maven

2. Run etl script:

>test4.etl

It will generate text report (report.txt).
