This example shows how to produce and send E-Mails from Scriptella.

Modify mail.properties and specify smtp host and additional parameters.
Modify users.sql and specify email accounts to send demo emails.

Type scriptella to run the example.
