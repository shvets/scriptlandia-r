1. Get required libraries:

>../get-libraries.maven

2. Run etl script:

>test1.etl

or ant script:

>test1.ant 