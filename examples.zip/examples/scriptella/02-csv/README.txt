1. Get required libraries:

>../get-libraries.maven

2. Run etl script:

>test2.etl

It uses bugs-in.csv file as input. The following files will be generated:

- bugs-out.csv 
- bugs-out-filtered.csv 