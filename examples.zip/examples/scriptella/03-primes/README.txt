1. Get required libraries:

>../get-libraries.maven

2. Run etl script:

>test3.etl

It will generate random numbers (report.csv). These numbers will be used as input for
html report (report.html).
