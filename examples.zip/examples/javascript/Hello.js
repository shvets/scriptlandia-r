// hello.js

importPackage(Packages.java.lang);

System.out.println("Hello!!!");
