// locale.js

importPackage(Packages.java.lang);
importPackage(Packages.java.util);

System.out.println("Locale: " + Locale.getDefault());
